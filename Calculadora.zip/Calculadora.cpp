#include "Calculadora.h"

int Calculadora::Sumar(int num1, int num2) {
    return num1 + num2;
}
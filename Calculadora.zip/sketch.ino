#include "Calculadora.h"

// Creamos el objeto (instanciamos)
Calculadora miCalculadora;

void setup() {
  // Iniciamos el monitor serial a 115200 baudios (la velocidad estándar de la ESP32)
  Serial.begin(115200);

  // Llamamos a la función y guardamos el dato
  int resultado = miCalculadora.Sumar(5, 7);

  // Imprimimos el resultado en pantalla
  Serial.println("Iniciando sistema...");
  Serial.print("El resultado de la suma es: ");
  Serial.println(resultado);
}

void loop() {
  // Queda vacío porque solo queremos hacer el cálculo una vez al encender
}

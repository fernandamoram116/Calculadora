#ifndef CALCULADORA_H
#define CALCULADORA_H

class Calculadora {
public:
    int Sumar(int num1, int num2);
};

#endif